"""示例自定义切分算子：按 max_len 定长切分。

入口函数签名与契约一致（`migration-review/05-contracts.md` §4.3）：
    file_split(file_path: str, **args) -> list[{"content", "metadata"}]

- 读入纯文本后按 max_len 定长切分（不做语义切分，便于人工逐片核对边界）。
- 每片附带 metadata.source 与 metadata.chunk_index，供上层去重与溯源。
- 返回值必须是 JSON 可序列化结构（沙箱去 pickle 后通过 JSON 交换结果）。
"""

import os


def file_split(file_path: str, max_len: int = 200) -> list:
    """按定长切分文件，返回符合 ChunkNode 的切片列表。

    Args:
        file_path: 待切分的文本文件绝对路径（由 doc-pipeline 注入）。
        max_len: 每片最大字符数（由 defaultArgs 提供，可在执行时覆盖）。

    Returns:
        list[dict]: 形如 [{"content": str, "metadata": dict}, ...]。
    """
    with open(file_path, "r", encoding="utf-8") as f:
        text = f.read()

    source = os.path.basename(file_path)
    chunks = []
    start = 0
    length = len(text)

    while start < length:
        end = min(start + int(max_len), length)
        segment = text[start:end]
        if segment.strip():
            chunks.append({
                "content": segment,
                "metadata": {
                    "source": source,
                    "chunk_index": len(chunks),
                    "split_type": "sample_fixed_length",
                },
            })
        start = end

    return chunks
