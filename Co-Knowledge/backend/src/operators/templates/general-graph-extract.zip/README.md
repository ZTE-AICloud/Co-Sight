# 通用知识图谱算子（v1.2.0）

系统算子 `id=-6` 的源码包。v1.1.0 新增**可选** `extractionProfile`；
v1.2.0 强化 `general_attributes` 的国家/国籍属性抽取（国籍形容词归一为国家实体）。

| profile | 行为 |
|---|---|
| `general`（默认） | 与 v1.0.0 完全一致：原 prompt、原调用次数、原输出 |
| `general_attributes` | 在原 prompt 末尾追加属性抽取段；**仍然只调 1 次 LLM**；日期、国家、出生地等作为普通实体/关系追加，供 2Wiki 这类多跳 QA 使用 |

默认 `general` 保持存量行为；新建图谱库时显式选择属性模式即可启用。

2Wiki 端到端推荐组合：`general_attributes` + 工作流图谱节点 `include_edge_facts=true`
+ 规范化提示；实测见 [`docs/2wiki-attributes-20261102.md`](../../../docs/2wiki-attributes-20261102.md)。

## 安装到运行中的部署

算子文件与 zip 在 `kb-storage` 卷里，路径由 `operator` 表给出：

```bash
# 目录名与 zip 文件名以 operator 表的 operator_path / operator_zip_path 为准
docker cp deploy/operators/general-graph-extract/graph_extract.py \
  <rkb-container>:/data/kb/operator/<operator.operator_path 目录名>

# 同步更新 zip（README/config 保留），路径以 operator.operator_zip_path 为准
python3 - <<'PY'
import zipfile
src = 'deploy/operators/general-graph-extract'
zip_path = '/data/kb/operator_zip/<operator.operator_zip_path 文件名>'
# 在容器内执行或把该路径替换成宿主机卷路径
with zipfile.ZipFile(zip_path, 'a') as z:
    z.writestr('graph_extract.py', open(f'{src}/graph_extract.py', 'rb').read())
    z.writestr('config.json', open(f'{src}/config.json', 'rb').read())
PY
```

再跑 DB 迁移：

```bash
# v1.1.0：新增 operator_param.extractionProfile
python3 tools/migrate/20261031-graph-extraction-profile.py --apply --yes

# v1.2.0：国家/国籍 prompt 强化，operator.version 升到 1.2.0
python3 tools/migrate/20261102-graph-extraction-prompt.py --apply --yes

python3 tools/migrate/20261031-graph-extraction-profile.py --verify
python3 tools/migrate/20261102-graph-extraction-prompt.py --verify
```

> 只更新 zip/DB 版本不够：运行时真正执行的是 `operator.operator_path`
> 指向的文件。改完必须确认该文件包含新 prompt（例如 `Country examples`），
> 否则抽图会静默使用旧逻辑。

> 生产环境不要直接改建图请求绕过 DB 参数；前端下拉和 `operator_param` 是同一个来源。
