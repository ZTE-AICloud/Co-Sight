# 🧩 知识图谱抽取算子开发规范

> 本规范适用于所有在平台上线的**知识图谱抽取类算子**。  
> 所有开发者必须严格遵守，否则算子将无法通过审核或稳定运行。

---

## 1. 文件与入口（**强制**）

- ✅ **文件名必须为**：`graph_extract.py`  
- ✅ **入口函数必须为**：

  ```python
  def graph_extract(
      file_path: str,
      schema: dict,
      lang: str,
      transaction_id: str = "",
      kwargs: dict = None
  ) -> dict:
  ```

- 🔒 **原因**：平台通过 `config.json` 中 `"module": "graph_extract"` 动态导入该模块。  
  任意修改文件名或函数名将导致 **模块加载失败**。

---

## 2. 输入模式（二选一，需明确）

算子可选择以下**其中一种输入处理方式**，但必须保证输出一致。

### ✅ 模式 A：使用平台预切分 chunks（推荐）

- **输入路径**：`{file_path}/output/document_chunk.jsonl`  
- **格式**：JSONL，每行包含至少 `"text"` 字段  

### ✅ 模式 B：自行处理原始文件（高级）

- **输入路径**：`{file_path}/input/`（目录）  
- **算子职责**：
  - 遍历并解析 PDF/DOCX/TXT/MD 等格式
  - 自行实现文本分块逻辑
  - 处理解析失败、编码异常等边界情况
- **启用方式**：通过 `kwargs` 中的参数（如 `"use_raw_input": true`）
- **配置声明**：需在 `config.json` 的 `defaultArgs` 中声明控制参数

> 💡 默认应兼容模式 A；若支持模式 B，需在算子描述中明确说明。

---

## 3. 输出规范（**强制**）

- ✅ 必须生成以下两个文件：
  - `{file_path}/entities.jsonl`
  - `{file_path}/edges.jsonl`
- ✅ 格式：**JSONL**（每行一个合法 JSON 对象）
- ✅ **所有输出数据必须通过 `GraphChecker(schema)` 校验**
  - 校验失败 → 视为执行失败 → 返回错误码，**不得写入无效数据**

---

## 4. 返回值规范（**强制**）

- 返回值必须为字典，格式如下：

  ```python
  {
    "code": 0,    # 成功
    "message": {
      "en": "Knowledge graph generation completed",
      "zh": "知识图谱生成完成"
    }
  }
  ```

  或

  ```python
  {
    "code": -1,   # 失败
    "message": {
      "en": "Internal operator error, details: ...",
      "zh": "算子内部错误，详情：..."
    }
  }
  ```

- `code == 0` 表示成功，非 `0`（建议统一用 `-1`）表示失败
- 所有用户可见消息必须通过 `build_response_message(msg_code, *args)` 构建

---

## 5. 参数与配置（`config.json`）

- `module` 字段必须为 `"graph_extract"`
- 所有用户可配置参数必须在 `defaultArgs` 中声明，包括：
  - `argName`
  - `argType`（如 `str`, `int`, `bool`, `dict`）
  - `defaultValue`（类型需匹配）
  - `description`

- ✅ **LLM 配置应为 `dict` 类型**（如 `{"model": "...", "api_key": "..."}`），不得以字符串传递
- ✅ 若支持原始文件处理或进度反馈，需在描述中说明（无需额外参数，因 `kb_id` 由平台注入）

---

## 6. 错误处理（**强制**）

- ✅ **所有异常必须被捕获**，禁止未处理异常退出函数
- ✅ 必须通过统一接口返回错误：

  ```python
  return build_response_message("operator_exec_error", str(e))
  ```

- ✅ 预定义错误码（可扩展）：
  - `"success"`
  - `"llm_param_missing"`
  - `"document_chunk_missing"`（仅模式 A）
  - `"operator_exec_error"`

- ✅ 日志中需记录完整异常栈：`logger.exception("...")`

---

## 7. 日志规范（**强制**）

- ✅ 必须使用带事务 ID 的日志器：

  ```python
  from operator_api.logging import TxPrefixedLogger
  logger = TxPrefixedLogger(transaction_id)
  ```

- ✅ 关键步骤需记录 `info` 级日志：
  - 开始执行
  - 输入模式判断
  - 文件读取/解析
  - LLM 调用
  - 校验结果
  - 写入输出
- ❌ **禁止使用 `print()`**

---

## 8. 国际化（i18n）

- ✅ 所有用户消息必须通过 `message_dict` 管理
- ✅ 消息模板使用 `{}` 作为位置占位符，支持多参数填充
- ✅ 中英文消息必须语义一致，不得缺失或直译错误

示例：
```python
"operator_exec_error": {
  "en": "Internal operator error, details: {}",
  "zh": "算子内部错误，详情：{}"
}
```

---

## 9. 安全与稳定性（**强制**）

- ❌ **禁止硬编码**：
  - API Key、模型名称、URL、路径、密钥等
- ⏱ **网络请求必须设置超时**
- 📦 **大文件处理需流式读取，避免内存溢出**
- 🔁 **算子应具备幂等性**：相同输入 → 相同输出
- 📈 **高并发下资源可控**，不得引发 OOM 或长时间阻塞

---

## 10. 进度更新机制（**推荐，长任务必选**）

### ✅ 使用场景
- 算子执行时间 > 10 秒
- 处理大量 chunks 或原始文件
- 需向用户实时反馈进展（如“正在处理第 X / N 块”）

### ✅ 实现方式
1. **获取知识库 ID**（由平台注入）：

   ```python
   kb_id = kwargs.get("kb_id")
   ```

2. **初始化进度更新器**：

   ```python
   from operator_api.graph import GraphProcess  # 假设位于 client/

   if kb_id:
       progress_updater = GraphProcess(transaction_id)
   ```

3. **在关键阶段上报进度**：

   ```python
   if kb_id and progress_updater:
       progress_updater.update_kbase_process(
           kb_id=kb_id,
           process="30",  # 字符串形式的百分比（"0" ~ "100"）
           process_info_zh="总共有 1000 块，正在处理第 300 块。",
           process_info_en="Processing chunk 300 of 1000."
       )
   ```

### ✅ 参数说明（`update_kbase_process`）

| 参数 | 类型 | 要求 |
|------|------|------|
| `kb_id` | `str` | 必填，由平台通过 `kwargs` 注入 |
| `process` | `str` | 百分比字符串，如 `"0"`, `"50"`, `"100"` |
| `process_info_zh` | `str` | 中文进度描述 |
| `process_info_en` | `str` | 英文进度描述 |

> ⚠️ 注意：
> - `process` 是 **字符串**，不是数字
> - 若 `kb_id` 不存在，应静默跳过进度更新
> - 进度更新失败**不得中断主流程**

### ✅ 典型上报点
- 开始：`process="0"`
- 处理中：按比例更新（如每 10%）
- 校验完成：`process="90"`
- 完成：`process="100"`

---

## ✅ 审核清单（发布前必查）

| 检查项 | 是否满足 |
|-------|--------|
| 文件名为 `graph_extract.py`？ | ✅ / ❌ |
| 入口函数为 `graph_extract(...)`？ | ✅ / ❌ |
| `config.json` 中 `module` 为 `"graph_extract"`？ | ✅ / ❌ |
| 输出 `entities.jsonl` 和 `edges.jsonl`？ | ✅ / ❌ |
| 所有输出通过 `GraphChecker(schema)` 校验？ | ✅ / ❌ |
| 所有异常被捕获并格式化返回？ | ✅ / ❌ |
| 无 `print()`，使用 `TxPrefixedLogger`？ | ✅ / ❌ |
| 消息支持中英文，通过 `build_response_message` 返回？ | ✅ / ❌ |
| 无硬编码敏感信息？ | ✅ / ❌ |
| 若使用原始文件，已声明 `use_raw_input` 等参数？ | ✅ / ❌ |
| **长任务是否通过 `GraphProcess` 更新进度**？ | ✅ / ❌ |
| **进度值为字符串（如 `"50"`）**？ | ✅ / ❌ |
| **进度更新失败不影响主流程**？ | ✅ / ❌ |

> ⚠️ **任一强制项不满足，算子将被拒绝上线**。  
> 💡 进度更新虽非强制，但**强烈推荐**用于生产级算子。

---

本规范为平台算子开发的**唯一权威标准**，请严格遵循。  
规范将随平台演进持续更新，请关注最新版本。