import hashlib
import json
import os
import re
from typing import Any, Dict, List, Optional

from operator_api.graph import GraphChecker
from operator_api.graph import GraphProcess
from operator_api.logging import TxPrefixedLogger

# =============================================================================
# 国际化消息字典
# =============================================================================
MESSAGE_DICT = {
    "success": {
        "en": "Knowledge graph generation completed",
        "zh": "知识图谱生成完成"
    },
    "llm_param_missing": {
        "en": "LLM parameters missing",
        "zh": "LLM参数缺失"
    },
    "document_chunk_missing": {
        "en": "Input file 'document_chunk.jsonl' not found",
        "zh": "输入文件 'document_chunk.jsonl' 不存在"
    },
    "schema_missing": {
        "en": "Schema is missing or has no entity definitions",
        "zh": "schema 缺失或未定义任何实体类型"
    },
    "no_data_extracted": {
        "en": "No valid entity/edge extracted from any chunk",
        "zh": "所有文本块均未抽取出合法的实体/关系"
    },
    "operator_exec_error": {
        "en": "Internal operator error, details: {}",
        "zh": "算子内部错误，详情：{}"
    }
}


def build_response_message(msg_code: str, *args) -> Dict[str, Any]:
    """构建标准化多语言响应消息，支持占位符替换。"""
    code = 0 if msg_code.strip().lower() == "success" else -1
    templates = MESSAGE_DICT.get(msg_code, {"en": "Unknown error", "zh": "未知错误"})

    formatted_msg = {}
    for lang, template in templates.items():
        try:
            formatted_msg[lang] = template.format(*args)
        except (IndexError, ValueError, KeyError):
            formatted_msg[lang] = template

    return {"code": code, "message": formatted_msg}


# =============================================================================
# LLM 提示词模板
#
# 与旧版本的区别：schema 是**运行时拼进去**的。旧版只说「实体类型必须在 schema.entities
# 中定义」却没把 schema 放进来，模型无从得知有哪些类型和属性，抽出来的东西必然过不了
# GraphChecker。schema_block 由 build_schema_block() 生成。
# =============================================================================
PROMPT_TEMPLATE = """你是知识图谱抽取助手。请从给定文本中抽取实体与关系，严格遵循下面的 schema。

{schema_block}

输出要求：
- 只输出一个 JSON 对象，不要输出任何解释文字、不要用 markdown 代码块包裹
- 结构固定为：{{"entities": [...], "relationships": [...]}}
- 实体：{{"entity_name": "实体名称", "entity_type": "上面列出的某个实体类型", "entity_description": "该实体在此文本中的描述"}}
- 关系：{{"source_entity": "源实体名称", "target_entity": "目标实体名称", "edge_type": "上面列出的某个关系类型", "relationship_description": "关系描述"}}
- source_entity / target_entity 必须出现在本次输出的 entities 里
- 实体类型与关系类型只能取自上面列出的清单，不得自创
- 与原文使用同一种语言（原文是中文就用中文），不要中英混排
- 文本中没有可抽取内容时，输出 {{"entities": [], "relationships": []}}

待抽取文本：
{text}
"""


def build_schema_block(schema: Dict[str, Any]) -> str:
    """把 schema 渲染成提示词里的一段说明（实体类型 + 属性、关系类型 + 端点与属性）。"""
    lines: List[str] = ["允许的实体类型（entity_type 只能取这些值）："]
    for ent in schema.get("entities") or []:
        etype = ent.get("entity_type", "")
        props = ent.get("properties") or []
        prop_desc = "、".join(
            f"{p.get('name')}({p.get('type', 'STRING')})" for p in props if p.get("name")
        ) or "（无）"
        primary = "、".join(
            p.get("name", "") for p in props if p.get("is_primary")
        )
        line = f"- {etype}：属性 {prop_desc}"
        if primary:
            line += f"；其中 {primary} 为必填主键，不能为空"
        lines.append(line)

    lines.append("")
    lines.append("允许的关系类型（edge_type 只能取这些值）：")
    for edge in schema.get("edges") or []:
        etype = edge.get("edge_type", "")
        src = edge.get("source_entity", "")
        tgt = edge.get("target_entity", "")
        props = edge.get("properties") or []
        prop_desc = "、".join(
            f"{p.get('name')}({p.get('type', 'STRING')})" for p in props if p.get("name")
        ) or "（无）"
        lines.append(f"- {etype}：（{src}）→（{tgt}）；属性 {prop_desc}")
    return "\n".join(lines)


# =============================================================================
# 解析工具
# =============================================================================
_FENCE_RE = re.compile(r"^\s*```(?:json)?\s*|\s*```\s*$", re.IGNORECASE)


def _extract_json(raw: str) -> Optional[Dict[str, Any]]:
    """
    从模型输出里尽力取出一个 JSON 对象。

    模型输出不可靠，常见的三种脏法：外面裹 markdown 代码块、前面带解释文字、
    结尾多一个逗号。这里逐级降级尝试，全部失败才返回 None（调用方跳过该块，
    而不是让整个算子失败）。
    """
    if not raw or not raw.strip():
        return None

    candidate = _FENCE_RE.sub("", raw.strip())

    first = candidate.find("{")
    last = candidate.rfind("}")
    if first != -1 and last > first:
        candidate = candidate[first:last + 1]

    for attempt in (candidate, candidate.rstrip().rstrip(",")):
        try:
            parsed = json.loads(attempt)
        except (json.JSONDecodeError, ValueError):
            continue
        if isinstance(parsed, dict):
            return parsed
        # 模型偶尔直接输出一个数组，包一层
        if isinstance(parsed, list):
            return {"entities": parsed, "relationships": []}
    return None


def _slug(value: str, max_len: int = 40) -> str:
    """
    把任意文本压成可安全放进 entity_id / edge_id 的片段。

    GraphChecker 要求 id 以 "{type}_" 开头，且 Java 侧建了 UNIQUE 索引，
    故同一名称必须稳定映射到同一 id —— 这里用哈希后缀保证稳定性与唯一性。
    """
    cleaned = re.sub(r"[^0-9A-Za-z一-龥]+", "", str(value or ""))
    digest = hashlib.sha1(str(value or "").encode("utf-8")).hexdigest()[:8]
    return f"{cleaned[:max_len] or 'x'}_{digest}"


def _default_for_type(type_name: str) -> Any:
    t = (type_name or "").upper()
    if t in ("INTEGER", "LONG", "SHORT", "BYTE"):
        return 0
    if t in ("FLOAT", "DOUBLE"):
        return 0.0
    if t == "BOOLEAN":
        return False
    return ""


def _conform_properties(raw_props: Dict[str, Any], prop_defs: List[Dict[str, Any]],
                        extra: Dict[str, Any]) -> Dict[str, Any]:
    """
    按 schema 的属性定义整理属性：丢弃未定义的、按定义类型补默认值、并入 extra（如 chunk_id）。

    必须「精确匹配」schema 的属性集，否则 GraphChecker 会以属性个数不符为由拒绝整条记录。
    extra 在 schema 属性之后覆盖，用于放入 schema 未声明但必须存在的字段（如 chunk_id）。
    """
    out: Dict[str, Any] = {}
    for prop in prop_defs or []:
        name = prop.get("name")
        if not name:
            continue
        value = raw_props.get(name)
        if value is None or value == "":
            value = _default_for_type(prop.get("type"))
        out[name] = value
    for key, value in (extra or {}).items():
        if value is None:
            continue
        # 只补空值，不覆盖模型/调用方已经填好的内容
        if key in out and out[key] not in ("", None, 0, 0.0, False):
            continue
        out[key] = value
    return out


def _apply_field_conventions(raw_props: Dict[str, Any], prop_defs: List[Dict[str, Any]],
                             entity_name: Any, description: Any) -> None:
    """
    把模型的通用字段（entity_name / entity_description）映射到 schema 自定义的属性名上。

    模型不知道 schema 里主键叫什么，输出的一律是 entity_name；而 schema 可能把主键命名为
    name / 名称 / title 等。不映射的话主键为空，GraphChecker 会以「主键不能为空」丢掉整条记录
    （实测踩到过）。这里按约定补：
      - schema 中标了 is_primary 的属性 <- entity_name
      - 名字里含 desc/描述 的属性     <- entity_description
    """
    if not prop_defs:
        return
    if entity_name not in (None, ""):
        for prop in prop_defs:
            if prop.get("is_primary") and prop.get("name") and not raw_props.get(prop["name"]):
                raw_props[prop["name"]] = entity_name
                break
    if description not in (None, ""):
        for prop in prop_defs:
            name = prop.get("name") or ""
            if prop.get("is_primary"):
                continue
            if ("desc" in name.lower() or "描述" in name) and not raw_props.get(name):
                raw_props[name] = description
                break


def _normalize_entities(parsed: Dict[str, Any], schema: Dict[str, Any],
                        chunk_id: str) -> List[Dict[str, Any]]:
    """把模型输出的 entities 规范化成 GraphChecker 能接受的结构。"""
    by_type = {e.get("entity_type"): e for e in (schema.get("entities") or [])}
    out: List[Dict[str, Any]] = []
    for item in parsed.get("entities") or []:
        if not isinstance(item, dict):
            continue
        etype = item.get("entity_type")
        definition = by_type.get(etype)
        if definition is None:
            continue  # 类型不在 schema 内，直接丢弃
        name = item.get("entity_name") or item.get("name") or ""
        if not str(name).strip():
            continue
        raw_props = dict(item.get("properties") or {})
        # 模型常用扁平字段，按 schema 属性名回填
        for prop in definition.get("properties") or []:
            pname = prop.get("name")
            if pname and pname not in raw_props and pname in item:
                raw_props[pname] = item[pname]
        # 再按约定把 entity_name / entity_description 落到 schema 自定义的属性名上
        _apply_field_conventions(raw_props, definition.get("properties"),
                                 name, item.get("entity_description"))
        out.append({
            "entity_id": f"{etype}_{_slug(name)}",
            "entity_type": etype,
            "entity_name": name,
            "properties": _conform_properties(raw_props, definition.get("properties"), {
                "chunk_id": chunk_id,
            }),
        })
    return out


def _normalize_edges(parsed: Dict[str, Any], schema: Dict[str, Any],
                     entities: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """把模型输出的 relationships 规范化；端点必须落在本次抽出的实体里。"""
    by_type = {e.get("edge_type"): e for e in (schema.get("edges") or [])}
    name_to_id = {e.get("entity_name"): e.get("entity_id") for e in entities}

    out: List[Dict[str, Any]] = []
    seen = set()
    for item in parsed.get("relationships") or parsed.get("edges") or []:
        if not isinstance(item, dict):
            continue
        etype = item.get("edge_type") or item.get("relationship_type")
        definition = by_type.get(etype)
        if definition is None:
            continue
        src_name = item.get("source_entity") or item.get("source_id")
        tgt_name = item.get("target_entity") or item.get("target_id")
        source_id = name_to_id.get(src_name)
        target_id = name_to_id.get(tgt_name)
        if not source_id or not target_id or source_id == target_id:
            continue  # 端点缺失或自环，丢弃

        edge_id = f"{etype}_{_slug(f'{src_name}->{tgt_name}')}"
        if edge_id in seen:
            continue
        seen.add(edge_id)

        raw_props = dict(item.get("properties") or {})
        # 边的属性没有主键概念，只需要把 relationship_description 映射到 schema 的描述类属性
        _apply_field_conventions(raw_props, definition.get("properties"),
                                 None, item.get("relationship_description"))
        out.append({
            "edge_id": edge_id,
            "edge_type": etype,
            "source_id": source_id,
            "target_id": target_id,
            "properties": _conform_properties(raw_props, definition.get("properties"), {}),
        })
    return out


# =============================================================================
# 算子入口
# =============================================================================
def graph_extract(
    file_path: str,
    schema: Dict[str, Any],
    lang: str,
    transaction_id: str = "",
    kwargs: Dict[str, Any] = None
) -> Dict[str, Any]:
    """
    知识图谱抽取算子主函数（符合平台最终规范）

    输入模式：模式 A（使用 {file_path}/output/document_chunk.jsonl）
    输出：entities.jsonl + edges.jsonl
    """
    kwargs = kwargs or {}
    logger = TxPrefixedLogger(transaction_id)
    logger.info(f"开始执行知识图谱抽取: file_path={file_path}, lang={lang}, kwargs_keys={list(kwargs.keys())}")

    kb_id = kwargs.get("kb_id")
    progress_updater = GraphProcess(transaction_id) if kb_id else None

    try:
        # ---------------------------------------------------------------------
        # 1. 参数校验
        # ---------------------------------------------------------------------
        if not kwargs.get("llm"):
            logger.error("缺少必需参数: 'llm'（LLM 配置字典）")
            return build_response_message("llm_param_missing")

        if not schema or not (schema.get("entities") or []):
            logger.error("schema 缺失或未定义任何实体类型")
            return build_response_message("schema_missing")

        # ---------------------------------------------------------------------
        # 2. 检查输入文件（模式 A）
        # ---------------------------------------------------------------------
        input_file = os.path.join(file_path, "output", "document_chunk.jsonl")
        if not os.path.exists(input_file):
            logger.error(f"输入文件不存在: {input_file}")
            return build_response_message("document_chunk_missing")

        # ---------------------------------------------------------------------
        # 3. 加载所有 chunks
        # ---------------------------------------------------------------------
        chunks: List[Dict[str, Any]] = []
        with open(input_file, 'r', encoding='utf-8') as f:
            for line in f:
                if line.strip():
                    chunks.append(json.loads(line))

        total = len(chunks)
        logger.info(f"共加载 {total} 个文本块")

        graph_checker = GraphChecker(schema)
        schema_block = build_schema_block(schema)
        prompt_template = PROMPT_TEMPLATE.replace("{schema_block}", schema_block)

        all_entities: List[Dict[str, Any]] = []
        all_edges: List[Dict[str, Any]] = []
        seen_entity_ids = set()
        seen_edge_ids = set()

        if progress_updater:
            progress_updater.update_kbase_process(
                kb_id=kb_id,
                process="0",
                process_info_zh=f"开始处理 {total} 个文本块",
                process_info_en=f"Start processing {total} chunks"
            )

        # 平台在沙箱里提供该模块
        from operator_api.llm import invoke_llm

        # ---------------------------------------------------------------------
        # 4. 遍历 chunks，调用 LLM 抽取
        # ---------------------------------------------------------------------
        for idx, chunk in enumerate(chunks):
            try:
                # 注意：document_chunk.jsonl 的正文在 **content_expand**，没有 text 字段；
                # chunk 标识是 **id**。旧模板读 chunk["text"]，实际永远取到空串，
                # 于是「跑通了但一条都抽不出来」。字段名与预设算子保持一致。
                text = chunk.get("content_expand") or chunk.get("text") or ""
                if not text:
                    continue
                chunk_id = str(chunk.get("id") or chunk.get("chunk_id") or idx)

                prompt = prompt_template.replace("{text}", text)
                # invoke_llm 接受 messages 列表；旧版按 (model, prompt) 位置参数调用是不通的
                llm_output = invoke_llm(
                    messages=[{"role": "user", "content": prompt}],
                    model=(kwargs.get("llm") or {}).get("model") if isinstance(kwargs.get("llm"), dict)
                    else kwargs.get("llm"),
                    temperature=0.1,
                    # 平台为「模型管理页新增的模型」下发端点（见 operator_api.llm）；
                    # .env 播种的模型不带它，仍走 MODEL_GATEWAY_URL。
                    endpoint=kwargs.get("llmConfig") or None,
                )

                parsed = _extract_json(llm_output)
                if not parsed:
                    logger.warning(f"chunk {idx}: 模型输出无法解析为 JSON，跳过")
                    continue

                entities = _normalize_entities(parsed, schema, chunk_id)
                edges = _normalize_edges(parsed, schema, entities)

                for ent in entities:
                    if ent["entity_id"] in seen_entity_ids:
                        continue
                    seen_entity_ids.add(ent["entity_id"])
                    all_entities.append(ent)
                for edge in edges:
                    if edge["edge_id"] in seen_edge_ids:
                        continue
                    seen_edge_ids.add(edge["edge_id"])
                    all_edges.append(edge)

            except Exception as e:
                logger.warning(f"处理 chunk {idx} 时出错，跳过: {e}")
                continue

            if progress_updater and total > 0:
                progress_val = min(90, int((idx + 1) / total * 90))
                if (idx + 1) % max(1, total // 10) == 0 or idx == total - 1:
                    progress_updater.update_kbase_process(
                        kb_id=kb_id,
                        process=str(progress_val),
                        process_info_zh=f"已处理 {idx + 1}/{total} 块",
                        process_info_en=f"Processed {idx + 1}/{total} chunks"
                    )

        logger.info(f"抽取完成：实体 {len(all_entities)} 条，关系 {len(all_edges)} 条")

        # ---------------------------------------------------------------------
        # 5. 校验与修复
        #
        # 旧版对单条不合格记录直接 return，等于「一个坏实体毁掉整张图」。
        # 这里改为：先用 GraphChecker 的 validate_and_fix_* 补齐缺失的非主键属性，
        # 仍不合格的单条丢弃并告警，不影响其余数据。
        # ---------------------------------------------------------------------
        entity_defs = {e.get("entity_type"): e for e in (schema.get("entities") or [])}
        edge_defs = {e.get("edge_type"): e for e in (schema.get("edges") or [])}

        validated_entities: List[Dict[str, Any]] = []
        for ent in all_entities:
            definition = entity_defs.get(ent.get("entity_type"))
            if definition is None:
                continue
            fixed, error = graph_checker.validate_and_fix_entity_properties(
                ent.get("properties") or {}, definition)
            if error:
                logger.warning(f"实体属性修复失败，丢弃: {error}, 实体: {ent.get('entity_id')}")
                continue
            candidate = dict(ent)
            candidate["properties"] = fixed
            is_valid, error_msg = graph_checker.check_entity_data(candidate)
            if not is_valid:
                logger.warning(f"实体校验不通过，丢弃: {error_msg}, 实体: {ent.get('entity_id')}")
                continue
            validated_entities.append(candidate)

        valid_entity_ids = {e.get("entity_id") for e in validated_entities}
        validated_edges: List[Dict[str, Any]] = []
        for edge in all_edges:
            definition = edge_defs.get(edge.get("edge_type"))
            if definition is None:
                continue
            # 端点必须落在最终保留的实体里，否则 OrientDB 建边时找不到顶点
            if edge.get("source_id") not in valid_entity_ids or edge.get("target_id") not in valid_entity_ids:
                logger.warning(f"关系端点不在有效实体中，丢弃: {edge.get('edge_id')}")
                continue
            fixed, error = graph_checker.validate_and_fix_edge_properties(
                edge.get("properties") or {}, definition)
            if error:
                logger.warning(f"关系属性修复失败，丢弃: {error}, 关系: {edge.get('edge_id')}")
                continue
            candidate = dict(edge)
            candidate["properties"] = fixed
            is_valid, error_msg = graph_checker.check_edge_data(candidate)
            if not is_valid:
                logger.warning(f"关系校验不通过，丢弃: {error_msg}, 关系: {edge.get('edge_id')}")
                continue
            validated_edges.append(candidate)

        # ---------------------------------------------------------------------
        # 6. 写入输出文件
        # ---------------------------------------------------------------------
        if validated_entities:
            with open(os.path.join(file_path, "entities.jsonl"), "w", encoding="utf-8") as f:
                for ent in validated_entities:
                    f.write(json.dumps(ent, ensure_ascii=False) + "\n")

        if validated_edges:
            with open(os.path.join(file_path, "edges.jsonl"), "w", encoding="utf-8") as f:
                for edge in validated_edges:
                    f.write(json.dumps(edge, ensure_ascii=False) + "\n")

        if not validated_entities:
            logger.error("所有文本块均未抽取出合法实体")
            return build_response_message("no_data_extracted")

        # ---------------------------------------------------------------------
        # 7. 完成 & 返回
        # ---------------------------------------------------------------------
        if progress_updater:
            progress_updater.update_kbase_process(
                kb_id=kb_id,
                process="100",
                process_info_zh="知识图谱生成完成",
                process_info_en="Knowledge graph generation completed"
            )

        logger.info("知识图谱抽取流程完成")
        return build_response_message("success")

    except Exception as e:
        logger.exception("算子执行过程中发生未预期异常")
        return build_response_message("operator_exec_error", str(e))
