# 算子导入文件目录要求


## 文本解析算子(file_parse)

算子包格式要求

压缩包名称不做要求，但文件扩展名必须是zip

压缩包内必须有config.json和file_parse.py两个文件，且两个文件需存放在压缩包根目录下；两个文件编码方式必须为UTF-8，换行符建议使用Linux的LF，否则不保证算子能正常导入
```
text_split.zip
├── config.json
└── file_parse.py
```

### 算子配置文件config.json各字段要求

|      字段名      |    类型    | 是否必填 |      字段含义       |                                                                            备注                                                                             |
| --------------- | --------- | -------- | ------------------ | ---------------------------------------------------------------------------------------------------------------------------------------------------------- |
| display_name    | dict      | Y        | 算子名称            | 不超过50字符。算子名称不能重复                                                                                                                                |
| desc            | str       |          | 算子描述            | 不超过5000字符                                                                                                                                              |
| visibleRange    | str       | Y        | 算子可见范围         | 可选值：public（公开）/private（私有）                                                                                                                        |
| version         | str       | Y        | 用户定义的算子版本号 | 不超过32字符。格式为三段式版本号（例如1[.xx[.xx]]），使用的正则表达式为`^(?=.{1,32}$)([1-9][\d]*)(\.(\d\\|[1-9][\d]*)){2}$`。请确保自定义的版本号符合该正则匹配规则 |
| supportedFormat | List[str] | Y        | 算子支持文档类型     | 必须支持至少一种文件格式；文件扩展名字母必须小写；不能为null或空字符串<br/>示例：[ "doc", "docx" ]                                                                |
| defaultArgs     | dict      |          | 算子默认参数         | argName：参数名(首字母必须为英文，不超过20字符)， argType:参数类型 支持类型有int、str、bool ，defaultValue：参数默认值 ，description:参数描述                      |
| is_published    | str       |          | 算子是否发布         | 0 未发布，1 发布     

### 文本解析算子file_parse.py格式要求

```python
# import xxx
# from xxx import xxx

def file_parse(file_path: str, custom_args: str) -> str:
    '''
    该算子会将会输入文件进行解析清洗转换成markdown字符串
    用户编写算子时，方法定义、方法名、入参、出参等格式请保持不变，否则会影响算子运行

    :param text: str字符串
    :param custom_args: 算子的自定义参数。用户可通过配置算子参数来改变算子的行为方式（例如：是否保留页眉、页脚等）。参数格式自行定义，如果使用到自定义参数，请确保方法内部能正确读取到参数
    :return: str（平台会对file_parse方法的输出类型进行校验，如果不是str数组或存在类型为null(None)的字符串则判定文本切分失败）
    '''
    return str
```