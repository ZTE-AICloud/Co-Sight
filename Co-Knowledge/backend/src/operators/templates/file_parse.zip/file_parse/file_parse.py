
def file_parse(file_path: str, custom_args: str) -> str:
    '''
    该算子会将会输入文件进行解析清洗转换成markdown字符串
    用户编写算子时，方法定义、方法名、入参、出参等格式请保持不变，否则会影响算子运行

    :param text: str字符串
    :param custom_args: 算子的自定义参数。用户可通过配置算子参数来改变算子的行为方式（例如：是否保留页眉、页脚等）。参数格式自行定义，如果使用到自定义参数，请确保方法内部能正确读取到参数
    :return: str（平台会对file_parse方法的输出类型进行校验，如果不是str数组或存在类型为null(None)的字符串则判定文本切分失败）
    '''
    return str
    
