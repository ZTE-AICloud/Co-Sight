

def file_split(file_path: str, 
                header_level: int, 
                chunk_size: int = None, ):
    '''
    该算子会将会输入文件进行切分。
    用户编写算子时，方法定义、方法名、入参、出参等格式请保持不变，否则会影响算子运行
    
    :param file_path: 原始文件的存储路径。由平台方提供，用户算子得到文件路径后需自行使用合适的方法读取和解析文件
    :param custom_args: 算子的自定义参数。用户可通过配置算子参数来改变算子的行为方式（例如：是否保留页眉、页脚等）。参数格式自行定义，如果使用到自定义参数，请确保方法内部能正确读取到参数
    :return: [{"content":"", "metadata":{}}] （输出格式如上所示）
    :metadata标准字段：{"source":"","content_expand":"","pict_info":{}} 可扩充
    : source标识来源，content_expand标识补充内容，pict_info标识图片信息
    '''
    return [{"content":"", "metadata":{}}]

