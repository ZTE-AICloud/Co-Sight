# GraphSchemaObj 字段约束说明文档

本文档基于 `GraphSchemaValidator.java` 中的验证逻辑，详细说明 `GraphSchemaObj` 中各个字段的约束条件。所有字段名使用 JSON 字段名（snake_case 格式）。

## 目录

- [根级别字段](#根级别字段)
- [实体定义 (entities)](#实体定义-entities)
- [实体属性 (properties)](#实体属性-properties)
- [边定义 (edges)](#边定义-edges)
- [边属性 (properties)](#边属性-properties)
- [SQL 保留关键字](#sql-保留关键字)
- [属性类型枚举值](#属性类型枚举值)

---

## 根级别字段

### schema_id

- **类型**: `String`
- **必填**: 否（可选）
- **说明**: Schema 的唯一标识符，如果为空，系统会自动生成 UUID

---

### schema_name

- **类型**: `String`
- **必填**: 是
- **长度**: 1-30 个字符
- **格式要求**:
  - 仅允许：字母（a-z, A-Z）、数字（0-9）、下划线（_）、中文字符
  - 正则表达式: `^[a-zA-Z0-9_\u4e00-\u9fa5]+$`
- **示例**: `"用户图谱"`, `"user_graph"`, `"图谱_001"`

---

### schema_desc

- **类型**: `String`
- **必填**: 是
- **长度**: 1-1000 个字符
- **格式要求**:
  - 不能为全空格或空白字符
  - 允许：字母、数字、下划线、中文字符、空格、常见标点符号
  - 支持的标点符号：逗号(,，)、句号(.。)、感叹号(!！)、问号(?？)、冒号(:：)、分号(;；)、引号(''"")、括号(()（）[]{}）、破折号(-—)、省略号(…)
  - 正则表达式: `^[a-zA-Z0-9_\u4e00-\u9fa5\s,，.。!！?？:：;；''""()（）\[\]{}\-—…]+$`
- **示例**: `"这是一个用户关系图谱，用于描述用户之间的关联关系。"`

---

## 实体定义 (entities)

### entities

- **类型**: `Array<EntityDefinition>`
- **必填**: 是
- **约束**:
  - 不能为 `null` 或空数组 `[]`
  - 数组中的 `entity_type` 值不能重复

---

### entity_type

- **类型**: `String`
- **必填**: 是
- **长度**: 1-63 个字符
- **格式要求**:
  - 首字母必须为大写字母（A-Z）
  - 其余字符为英文字母（A-Z, a-z）和下划线（_）
  - 正则表达式: `^[A-Z][A-Za-z_]*$`
  - 不能为 SQL 保留关键字（不区分大小写）
- **示例**: `"Person"`, `"Company"`, `"User_Profile"`

---

### entity_desc

- **类型**: `String`
- **必填**: 是
- **长度**: 1-1000 个字符
- **格式要求**: 与 `schema_desc` 相同
  - 不能为全空格或空白字符
  - 允许：字母、数字、下划线、中文字符、空格、常见标点符号
  - 正则表达式: `^[a-zA-Z0-9_\u4e00-\u9fa5\s,，.。!！?？:：;；''""()（）\[\]{}\-—…]+$`
- **示例**: `"人物实体，表示系统中的用户信息"`

---

## 实体属性 (properties)

### properties (实体属性列表)

- **类型**: `Array<EntityPropertyDefinition>`
- **必填**: 是
- **约束**:
  - 不能为 `null` 或空数组 `[]`
  - 数组中的 `name` 值不能重复
  - 必须至少有一个属性的 `is_primary` 为 `true`

---

### name (属性名称)

- **类型**: `String`
- **必填**: 是
- **长度**: 1-63 个字符
- **格式要求**:
  - 必须以字母（a-z, A-Z）开头
  - 其余字符为字母、数字（0-9）和下划线（_）
  - 正则表达式: `^[a-zA-Z][a-zA-Z0-9_]*$`
  - 不能为 SQL 保留关键字（不区分大小写）
- **示例**: `"name"`, `"user_id"`, `"age"`, `"createTime"`

---

### type (属性类型)

- **类型**: `String`
- **必填**: 是
- **合法值**: 必须是 `GraphPropertyTypeEnum` 枚举中的值（不区分大小写）
- **可选值**:
  - `BOOLEAN` - 布尔值
  - `BYTE` - 8 位整数
  - `SHORT` - 16 位整数
  - `INTEGER` - 32 位整数（⚠️ 注意：不是 INT）
  - `LONG` - 64 位整数
  - `FLOAT` - 32 位浮点数
  - `DOUBLE` - 64 位浮点数
  - `DATE` - 日期（不含时间）
  - `DATETIME` - 日期时间
  - `STRING` - 字符串
  - `BINARY` - 二进制数据
  - `EMBEDDED` - 嵌入式文档
  - `EMBEDDEDLIST` - 嵌入式列表
  - `EMBEDDEDSET` - 嵌入式集合
  - `EMBEDDEDMAP` - 嵌入式映射
  - `LINK` - 单链接（指向另一记录）
  - `LINKLIST` - 链接列表
  - `LINKSET` - 链接集合
  - `LINKMAP` - 链接映射

---

### desc (属性描述)

- **类型**: `String`
- **必填**: 是
- **长度**: 1-1000 个字符
- **格式要求**: 与 `schema_desc` 相同
  - 不能为全空格或空白字符
  - 允许：字母、数字、下划线、中文字符、空格、常见标点符号
  - 正则表达式: `^[a-zA-Z0-9_\u4e00-\u9fa5\s,，.。!！?？:：;；''""()（）\[\]{}\-—…]+$`
- **示例**: `"用户姓名，字符串类型"`

---

### is_primary (是否主键)

- **类型**: `Boolean`
- **必填**: 是
- **约束**:
  - 每个实体的属性列表中，必须至少有一个属性的 `is_primary` 为 `true`
- **示例**: `true`, `false`

---

### is_embedding (是否嵌入向量)

- **类型**: `Boolean`
- **必填**: 否（可选）
- **说明**: 标识该属性是否用于嵌入向量计算

---

### is_index (是否索引)

- **类型**: `Boolean`
- **必填**: 否（可选）
- **说明**: 标识该属性是否创建索引

---

## 边定义 (edges)

### edges

- **类型**: `Array<EdgeDefinition>`
- **必填**: 否（可选，但建议提供）
- **约束**:
  - 如果提供，数组中的 `edge_type` 值不能重复

---

### edge_type

- **类型**: `String`
- **必填**: 是（如果提供了 `edges` 数组）
- **长度**: 1-63 个字符
- **格式要求**: 与 `entity_type` 相同
  - 首字母必须为大写字母（A-Z）
  - 其余字符为英文字母（A-Z, a-z）和下划线（_）
  - 正则表达式: `^[A-Z][A-Za-z_]*$`
  - 不能为 SQL 保留关键字（不区分大小写）
- **示例**: `"WorksAt"`, `"Knows"`, `"Friend_Of"`

---

### edge_desc

- **类型**: `String`
- **必填**: 是（如果提供了 `edges` 数组）
- **长度**: 1-1000 个字符
- **格式要求**: 与 `schema_desc` 相同
  - 不能为全空格或空白字符
  - 允许：字母、数字、下划线、中文字符、空格、常见标点符号
  - 正则表达式: `^[a-zA-Z0-9_\u4e00-\u9fa5\s,，.。!！?？:：;；''""()（）\[\]{}\-—…]+$`
- **示例**: `"就职关系，表示人员在公司的任职关系"`

---

### direction (边的方向)

- **类型**: `String`
- **必填**: 是（如果提供了 `edges` 数组）
- **说明**: 边的方向类型，如 `"one-way"`（单向）或 `"two-way"`（双向）

---

### source_entity (源实体类型)

- **类型**: `String`
- **必填**: 是（如果提供了 `edges` 数组）
- **约束**:
  - 必须在 `entities` 数组中的某个 `entity_type` 值
  - 不能引用不存在的实体类型

---

### target_entity (目标实体类型)

- **类型**: `String`
- **必填**: 是（如果提供了 `edges` 数组）
- **约束**:
  - 必须在 `entities` 数组中的某个 `entity_type` 值
  - 不能引用不存在的实体类型

---

## 边属性 (properties)

### properties (边属性列表)

- **类型**: `Array<EdgePropertyDefinition>`
- **必填**: 是（如果提供了 `edges` 数组）
- **约束**:
  - 不能为 `null` 或空数组 `[]`
  - 数组中的 `name` 值不能重复

---

### name (边属性名称)

- **类型**: `String`
- **必填**: 是
- **长度**: 1-63 个字符
- **格式要求**: 与实体属性的 `name` 相同
  - 必须以字母（a-z, A-Z）开头
  - 其余字符为字母、数字（0-9）和下划线（_）
  - 正则表达式: `^[a-zA-Z][a-zA-Z0-9_]*$`
  - 不能为 SQL 保留关键字（不区分大小写）

---

### type (边属性类型)

- **类型**: `String`
- **必填**: 是
- **合法值**: 与实体属性的 `type` 相同，必须是 `GraphPropertyTypeEnum` 枚举中的值

---

### desc (边属性描述)

- **类型**: `String`
- **必填**: 是
- **长度**: 1-1000 个字符
- **格式要求**: 与 `schema_desc` 相同

---

### is_embedding (是否嵌入向量)

- **类型**: `Boolean`
- **必填**: 否（可选）
- **说明**: 标识该属性是否用于嵌入向量计算

---

### is_index (是否索引)

- **类型**: `Boolean`
- **必填**: 否（可选）
- **说明**: 标识该属性是否创建索引

---

## SQL 保留关键字

以下关键字不能用作 `entity_type`、`edge_type` 或属性 `name`（不区分大小写）：

```
ORDER, GROUP, AS, AND, OR, FROM, WHERE, SELECT, INSERT,
UPDATE, DELETE, CREATE, DROP, ALTER, TABLE, INDEX, VIEW,
JOIN, INNER, LEFT, RIGHT, FULL, OUTER, ON, HAVING,
DISTINCT, UNION, INTERSECT, EXCEPT, LIMIT, OFFSET, NULL,
TRUE, FALSE, IS, NOT, IN, EXISTS, BETWEEN, LIKE,
CASE, WHEN, THEN, ELSE, END, CAST, COUNT, SUM, AVG,
MAX, MIN, IF, ELSEIF, WHILE, FOR, DO, BEGIN,
VERTEX, EDGE
```

---

## 属性类型枚举值

### 基础类型

| 类型值 | 说明 |
|--------|------|
| `BOOLEAN` | 布尔值 |
| `BYTE` | 8 位整数 |
| `SHORT` | 16 位整数 |
| `INTEGER` | 32 位整数（⚠️ 注意：不是 INT） |
| `LONG` | 64 位整数 |
| `FLOAT` | 32 位浮点数 |
| `DOUBLE` | 64 位浮点数 |

### 日期时间类型

| 类型值 | 说明 |
|--------|------|
| `DATE` | 日期（不含时间） |
| `DATETIME` | 日期时间 |

### 字符串和二进制类型

| 类型值 | 说明 |
|--------|------|
| `STRING` | 字符串 |
| `BINARY` | 二进制数据 |

### 嵌入式类型

| 类型值 | 说明 |
|--------|------|
| `EMBEDDED` | 嵌入式文档 |
| `EMBEDDEDLIST` | 嵌入式列表 |
| `EMBEDDEDSET` | 嵌入式集合 |
| `EMBEDDEDMAP` | 嵌入式映射 |

### 链接类型

| 类型值 | 说明 |
|--------|------|
| `LINK` | 单链接（指向另一记录） |
| `LINKLIST` | 链接列表 |
| `LINKSET` | 链接集合 |
| `LINKMAP` | 链接映射 |

---

## JSON 示例

```json
{
  "schema_id": "schema-001",
  "schema_name": "用户关系图谱",
  "schema_desc": "用于描述用户之间的社交关系和工作关系",
  "entities": [
    {
      "entity_type": "Person",
      "entity_desc": "人物实体",
      "properties": [
        {
          "name": "name",
          "type": "STRING",
          "desc": "姓名",
          "is_primary": true,
          "is_embedding": false,
          "is_index": true
        },
        {
          "name": "age",
          "type": "INTEGER",
          "desc": "年龄",
          "is_primary": false,
          "is_embedding": false,
          "is_index": false
        }
      ]
    }
  ],
  "edges": [
    {
      "edge_type": "Knows",
      "edge_desc": "认识关系",
      "direction": "two-way",
      "source_entity": "Person",
      "target_entity": "Person",
      "properties": [
        {
          "name": "since",
          "type": "DATE",
          "desc": "认识日期",
          "is_embedding": false,
          "is_index": false
        }
      ]
    }
  ]
}
```

---

## 注意事项

1. **实体类型和边类型命名**: 首字母必须大写，建议使用 PascalCase 命名风格（如 `Person`, `Company`, `WorksAt`）

2. **属性名称命名**: 首字母必须小写，建议使用 camelCase 命名风格（如 `name`, `userId`, `createTime`）

3. **主键属性**: 每个实体必须至少有一个 `is_primary: true` 的属性

4. **实体引用**: 边的 `source_entity` 和 `target_entity` 必须引用已定义的实体类型

5. **唯一性约束**: 
   - `entity_type` 在同一 schema 中不能重复
   - `edge_type` 在同一 schema 中不能重复
   - 属性 `name` 在同一实体或边中不能重复

6. **SQL 关键字**: 避免使用 SQL 保留关键字作为类型名或属性名

---

**文档版本**: v1.0  
**最后更新**: 2025-12-26  
**基于**: `GraphSchemaValidator.java`

