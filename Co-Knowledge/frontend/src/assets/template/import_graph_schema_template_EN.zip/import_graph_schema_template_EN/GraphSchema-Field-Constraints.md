# GraphSchemaObj Field Constraints Documentation

This document is based on the validation logic in `GraphSchemaValidator.java` and describes the constraints for each field in `GraphSchemaObj`. All field names use JSON field names (snake_case format).

## Table of Contents

- [Root-Level Fields](#root-level-fields)
- [Entity Definitions (entities)](#entity-definitions-entities)
- [Entity Properties (properties)](#entity-properties-properties)
- [Edge Definitions (edges)](#edge-definitions-edges)
- [Edge Properties (properties)](#edge-properties-properties)
- [SQL Reserved Keywords](#sql-reserved-keywords)
- [Property Type Enum Values](#property-type-enum-values)

---

## Root-Level Fields

### schema_id

- **Type**: `String`
- **Required**: No (optional)
- **Description**: Unique identifier for the schema. If empty, the system will auto-generate a UUID.

---

### schema_name

- **Type**: `String`
- **Required**: Yes
- **Length**: 1-30 characters
- **Format Requirements**:
  - Allowed: letters (a-z, A-Z), digits (0-9), underscores (_), Chinese characters
  - Regular expression: `^[a-zA-Z0-9_一-龥]+$`
- **Examples**: `"User Graph"`, `"user_graph"`, `"Graph_001"`

---

### schema_desc

- **Type**: `String`
- **Required**: Yes
- **Length**: 1-1000 characters
- **Format Requirements**:
  - Must not be all spaces or whitespace characters
  - Allowed: letters, digits, underscores, Chinese characters, spaces, common punctuation
  - Supported punctuation: comma (,，), period (.。), exclamation mark (!！), question mark (?？), colon (:：), semicolon (;；), quotes (''""), parentheses (()（）[]{}), dash (-—), ellipsis (…)
  - Regular expression: `^[a-zA-Z0-9_一-龥\s,，.。!！?？:：;；''""()（）\[\]{}\-—…]+$`
- **Example**: `"This is a user relationship graph used to describe the association relationships between users."`

---

## Entity Definitions (entities)

### entities

- **Type**: `Array<EntityDefinition>`
- **Required**: Yes
- **Constraints**:
  - Must not be `null` or an empty array `[]`
  - `entity_type` values in the array must not be duplicated

---

### entity_type

- **Type**: `String`
- **Required**: Yes
- **Length**: 1-63 characters
- **Format Requirements**:
  - First character must be an uppercase letter (A-Z)
  - Remaining characters are English letters (A-Z, a-z) and underscores (_)
  - Regular expression: `^[A-Z][A-Za-z_]*$`
  - Must not be an SQL reserved keyword (case-insensitive)
- **Examples**: `"Person"`, `"Company"`, `"User_Profile"`

---

### entity_desc

- **Type**: `String`
- **Required**: Yes
- **Length**: 1-1000 characters
- **Format Requirements**: Same as `schema_desc`
  - Must not be all spaces or whitespace characters
  - Allowed: letters, digits, underscores, Chinese characters, spaces, common punctuation
  - Regular expression: `^[a-zA-Z0-9_一-龥\s,，.。!！?？:：;；''""()（）\[\]{}\-—…]+$`
- **Example**: `"Person entity, representing user information in the system"`

---

## Entity Properties (properties)

### properties (Entity Property List)

- **Type**: `Array<EntityPropertyDefinition>`
- **Required**: Yes
- **Constraints**:
  - Must not be `null` or an empty array `[]`
  - `name` values in the array must not be duplicated
  - At least one property must have `is_primary` set to `true`

---

### name (Property Name)

- **Type**: `String`
- **Required**: Yes
- **Length**: 1-63 characters
- **Format Requirements**:
  - Must start with a letter (a-z, A-Z)
  - Remaining characters are letters, digits (0-9), and underscores (_)
  - Regular expression: `^[a-zA-Z][a-zA-Z0-9_]*$`
  - Must not be an SQL reserved keyword (case-insensitive)
- **Examples**: `"name"`, `"user_id"`, `"age"`, `"createTime"`

---

### type (Property Type)

- **Type**: `String`
- **Required**: Yes
- **Valid Values**: Must be a value from the `GraphPropertyTypeEnum` enum (case-insensitive)
- **Options**:
  - `BOOLEAN` - Boolean value
  - `BYTE` - 8-bit integer
  - `SHORT` - 16-bit integer
  - `INTEGER` - 32-bit integer (⚠️ Note: not INT)
  - `LONG` - 64-bit integer
  - `FLOAT` - 32-bit floating-point number
  - `DOUBLE` - 64-bit floating-point number
  - `DATE` - Date (without time)
  - `DATETIME` - Date and time
  - `STRING` - String
  - `BINARY` - Binary data
  - `EMBEDDED` - Embedded document
  - `EMBEDDEDLIST` - Embedded list
  - `EMBEDDEDSET` - Embedded set
  - `EMBEDDEDMAP` - Embedded map
  - `LINK` - Single link (pointing to another record)
  - `LINKLIST` - Link list
  - `LINKSET` - Link set
  - `LINKMAP` - Link map

---

### desc (Property Description)

- **Type**: `String`
- **Required**: Yes
- **Length**: 1-1000 characters
- **Format Requirements**: Same as `schema_desc`
  - Must not be all spaces or whitespace characters
  - Allowed: letters, digits, underscores, Chinese characters, spaces, common punctuation
  - Regular expression: `^[a-zA-Z0-9_一-龥\s,，.。!！?？:：;；''""()（）\[\]{}\-—…]+$`
- **Example**: `"User name, string type"`

---

### is_primary (Is Primary Key)

- **Type**: `Boolean`
- **Required**: Yes
- **Constraints**:
  - In each entity's property list, at least one property must have `is_primary` set to `true`
- **Examples**: `true`, `false`

---

### is_embedding (Is Embedding Vector)

- **Type**: `Boolean`
- **Required**: No (optional)
- **Description**: Indicates whether this property is used for embedding vector computation.

---

### is_index (Is Indexed)

- **Type**: `Boolean`
- **Required**: No (optional)
- **Description**: Indicates whether an index is created for this property.

---

## Edge Definitions (edges)

### edges

- **Type**: `Array<EdgeDefinition>`
- **Required**: No (optional, but recommended)
- **Constraints**:
  - If provided, `edge_type` values in the array must not be duplicated

---

### edge_type

- **Type**: `String`
- **Required**: Yes (if `edges` array is provided)
- **Length**: 1-63 characters
- **Format Requirements**: Same as `entity_type`
  - First character must be an uppercase letter (A-Z)
  - Remaining characters are English letters (A-Z, a-z) and underscores (_)
  - Regular expression: `^[A-Z][A-Za-z_]*$`
  - Must not be an SQL reserved keyword (case-insensitive)
- **Examples**: `"WorksAt"`, `"Knows"`, `"Friend_Of"`

---

### edge_desc

- **Type**: `String`
- **Required**: Yes (if `edges` array is provided)
- **Length**: 1-1000 characters
- **Format Requirements**: Same as `schema_desc`
  - Must not be all spaces or whitespace characters
  - Allowed: letters, digits, underscores, Chinese characters, spaces, common punctuation
  - Regular expression: `^[a-zA-Z0-9_一-龥\s,，.。!！?？:：;；''""()（）\[\]{}\-—…]+$`
- **Example**: `"Employment relationship, representing a person's employment at a company"`

---

### direction (Edge Direction)

- **Type**: `String`
- **Required**: Yes (if `edges` array is provided)
- **Description**: The direction type of the edge, such as `"one-way"` or `"two-way"`.

---

### source_entity (Source Entity Type)

- **Type**: `String`
- **Required**: Yes (if `edges` array is provided)
- **Constraints**:
  - Must match an `entity_type` value in the `entities` array
  - Must not reference a non-existent entity type

---

### target_entity (Target Entity Type)

- **Type**: `String`
- **Required**: Yes (if `edges` array is provided)
- **Constraints**:
  - Must match an `entity_type` value in the `entities` array
  - Must not reference a non-existent entity type

---

## Edge Properties (properties)

### properties (Edge Property List)

- **Type**: `Array<EdgePropertyDefinition>`
- **Required**: Yes (if `edges` array is provided)
- **Constraints**:
  - Must not be `null` or an empty array `[]`
  - `name` values in the array must not be duplicated

---

### name (Edge Property Name)

- **Type**: `String`
- **Required**: Yes
- **Length**: 1-63 characters
- **Format Requirements**: Same as entity property `name`
  - Must start with a letter (a-z, A-Z)
  - Remaining characters are letters, digits (0-9), and underscores (_)
  - Regular expression: `^[a-zA-Z][a-zA-Z0-9_]*$`
  - Must not be an SQL reserved keyword (case-insensitive)

---

### type (Edge Property Type)

- **Type**: `String`
- **Required**: Yes
- **Valid Values**: Same as entity property `type`; must be a value from the `GraphPropertyTypeEnum` enum.

---

### desc (Edge Property Description)

- **Type**: `String`
- **Required**: Yes
- **Length**: 1-1000 characters
- **Format Requirements**: Same as `schema_desc`

---

### is_embedding (Is Embedding Vector)

- **Type**: `Boolean`
- **Required**: No (optional)
- **Description**: Indicates whether this property is used for embedding vector computation.

---

### is_index (Is Indexed)

- **Type**: `Boolean`
- **Required**: No (optional)
- **Description**: Indicates whether an index is created for this property.

---

## SQL Reserved Keywords

The following keywords must not be used as `entity_type`, `edge_type`, or property `name` (case-insensitive):

```
ORDER, GROUP, AS, AND, OR, FROM, WHERE, SELECT, INSERT,
UPDATE, DELETE, CREATE, DROP, ALTER, TABLE, INDEX, VIEW,
JOIN, INNER, LEFT, RIGHT, FULL, OUTER, ON, HAVING,
DISTINCT, UNION, INTERSECT, EXCEPT, LIMIT, OFFSET, NULL,
TRUE, FALSE, IS, NOT, IN, EXISTS, BETWEEN, LIKE,
CASE, WHEN, THEN, ELSE, END, CAST, COUNT, SUM, AVG,
MAX, MIN, IF, ELSEIF, WHILE, FOR, DO, BEGIN,
VERTEX, EDGE
```

---

## Property Type Enum Values

### Basic Types

| Type Value | Description |
|------------|-------------|
| `BOOLEAN` | Boolean value |
| `BYTE` | 8-bit integer |
| `SHORT` | 16-bit integer |
| `INTEGER` | 32-bit integer (⚠️ Note: not INT) |
| `LONG` | 64-bit integer |
| `FLOAT` | 32-bit floating-point number |
| `DOUBLE` | 64-bit floating-point number |

### Date/Time Types

| Type Value | Description |
|------------|-------------|
| `DATE` | Date (without time) |
| `DATETIME` | Date and time |

### String and Binary Types

| Type Value | Description |
|------------|-------------|
| `STRING` | String |
| `BINARY` | Binary data |

### Embedded Types

| Type Value | Description |
|------------|-------------|
| `EMBEDDED` | Embedded document |
| `EMBEDDEDLIST` | Embedded list |
| `EMBEDDEDSET` | Embedded set |
| `EMBEDDEDMAP` | Embedded map |

### Link Types

| Type Value | Description |
|------------|-------------|
| `LINK` | Single link (pointing to another record) |
| `LINKLIST` | Link list |
| `LINKSET` | Link set |
| `LINKMAP` | Link map |

---

## JSON Example

```json
{
  "schema_id": "schema-001",
  "schema_name": "User Relationship Graph",
  "schema_desc": "Used to describe social and work relationships between users",
  "entities": [
    {
      "entity_type": "Person",
      "entity_desc": "Person entity",
      "properties": [
        {
          "name": "name",
          "type": "STRING",
          "desc": "Name",
          "is_primary": true,
          "is_embedding": false,
          "is_index": true
        },
        {
          "name": "age",
          "type": "INTEGER",
          "desc": "Age",
          "is_primary": false,
          "is_embedding": false,
          "is_index": false
        }
      ]
    }
  ],
  "edges": [
    {
      "edge_type": "Knows",
      "edge_desc": "Acquaintance relationship",
      "direction": "two-way",
      "source_entity": "Person",
      "target_entity": "Person",
      "properties": [
        {
          "name": "since",
          "type": "DATE",
          "desc": "Acquaintance date",
          "is_embedding": false,
          "is_index": false
        }
      ]
    }
  ]
}
```

---

## Notes

1. **Entity type and edge type naming**: The first character must be uppercase. PascalCase naming style is recommended (e.g., `Person`, `Company`, `WorksAt`).

2. **Property name naming**: The first character must be lowercase. camelCase naming style is recommended (e.g., `name`, `userId`, `createTime`).

3. **Primary key property**: Each entity must have at least one property with `is_primary: true`.

4. **Entity references**: The `source_entity` and `target_entity` of an edge must reference already-defined entity types.

5. **Uniqueness constraints**: 
   - `entity_type` must not be duplicated within the same schema.
   - `edge_type` must not be duplicated within the same schema.
   - Property `name` must not be duplicated within the same entity or edge.

6. **SQL keywords**: Avoid using SQL reserved keywords as type names or property names.

---

**Document Version**: v1.0  
**Last Updated**: 2025-12-26  
**Based on**: `GraphSchemaValidator.java`
